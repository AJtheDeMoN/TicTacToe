to run the program both the TicTacToe and Playzone should be in the same folder and the enter javac TicTacToe.java
then enter java TicTacToe

Now,all the commands are given in the code 