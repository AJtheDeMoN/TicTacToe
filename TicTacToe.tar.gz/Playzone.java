import java.util.Random;

public class Playzone {
    public int[][] zone = new int[3][3];

    // Gives idea to the users what number to hit to play their mark
    public void Print() {
        System.out.println("");
        int x = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(x);
                if (j != 2)
                    System.out.print(" | ");
                x++;
            }
            System.out.println("");
            if (i != 2)
                System.out.println("---------");
        }
    }

    //Checks if the position is Empty or not 
    public boolean position_check(int pos) {
        pos--;
        int x = pos / 3;
        int y = pos % 3;
        if (zone[x][y] != 0) 
            return true; // If occupied return true
        else 
            return false; // If unoccupied return false
    }

    // Display the current situation of the zone
    public void Display() {
        System.out.println("");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (zone[i][j] == 0) 
                    System.out.print(" ");// If value is 0 that means it's empty
                else {
                    if (zone[i][j] == 1) 
                        System.out.print("X"); // If value is 1 that means 'X' is there
                    else 
                        System.out.print("O"); // If value is 2 that means 'O' is there
                }
                if(j!=2)
                System.out.print(" | ");
            }
            System.out.println("");
            if(i!=2)
            System.out.println("---------");
        }
    }

    public void update(int pos, int val) {
        pos--;
        int x = pos / 3;
        int y = pos % 3;
        zone[x][y] = val;
    }

    public int Win() {
        int sum;
        // 1 is for PLAYER 1 and 2 is for PLAYER 2
        // COLUMN checking
        for (int i = 0; i < 3; i++) {
            sum = 0;
            for (int j = 0; j < 3; j++) {
                if(zone[j][i]==0)
                sum+=7;
                sum += zone[j][i];
            }
            if (sum == 3) {
                return 1;
            } else if (sum == 6) {
                return 2;
            }
        }

        // ROW ckecking
        for (int i = 0; i < 3; i++) {
            sum = 0;
            for (int j = 0; j < 3; j++) {
                if(zone[i][j]==0)
                sum+=7;
                sum += zone[i][j];
            }
            if (sum == 3) {
                return 1;
            } else if (sum == 6) {
                return 2;
            }
        }
        sum = 0;

        //Diagonal Checking(from top left to bottom right)
        for (int i = 0; i < 3; i++) {
            if(zone[i][i] == 0)
            sum+=7;
            sum += zone[i][i];
        }
        if (sum == 3) {
            return 1;
        } else if (sum == 6) {
            return 2;
        }

        sum = 0;

        //Diagnol checking (from top right to bottom left)
        for (int i = 0; i < 3; i++) {
            if(zone [i][2-i]==0)
            sum+=7;
            sum += zone[i][2 - i];
        }
        if (sum == 3) {
            return 1;
        } else if (sum == 6) {
            return 2;
        }

        // If no player wins then we return 0
        return 0;
    }

    public void computer() {
        int pos;

        Random random = new Random();
        pos = random.nextInt(9) + 1;
        while (position_check(pos) == true) {
            pos = random.nextInt(9) + 1;
        }
        update(pos, 2);
    }

}